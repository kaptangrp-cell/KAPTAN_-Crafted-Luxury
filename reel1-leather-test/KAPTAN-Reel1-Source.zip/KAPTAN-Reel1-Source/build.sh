#!/bin/bash
# usage: ./build.sh [licensed-track.mp3] [start-seconds]
# Put clips in ./clips: macro.mp4 water.mp4 flex.mp4 stitch.mp4 hand.mp4 (any size; filled to 1080x1920)
set -e
declare -A LEN=([macro]=3.2 [water]=1.9 [flex]=1.9 [stitch]=1.8 [hand]=4.2)
for n in macro water flex stitch hand; do
  if [ -f clips/$n.mp4 ]; then rm -rf fr/$n; mkdir -p fr/$n
    ffmpeg -y -loglevel error -i clips/$n.mp4 -t ${LEN[$n]} -vf "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30" -q:v 3 fr/$n/%04d.jpg; fi
done
python3 gen_reel1.py
node render.js reel1
printf "file 'reel1_s%d.mp4'\n" 0 1 2 3 > l.txt
ffmpeg -y -loglevel error -f concat -safe 0 -i l.txt -c copy reel1.silent.mp4
if [ -n "$1" ]; then
  ffmpeg -y -loglevel error -i reel1.silent.mp4 -ss ${2:-0} -t 15 -i "$1" -map 0:v -map 1:a -c:v copy -af "afade=t=out:st=14.4:d=0.6" -c:a aac -b:a 192k -shortest -movflags +faststart KAPTAN-Reel1-Final.mp4
else cp reel1.silent.mp4 KAPTAN-Reel1-Final.mp4; fi
echo "done: KAPTAN-Reel1-Final.mp4"
