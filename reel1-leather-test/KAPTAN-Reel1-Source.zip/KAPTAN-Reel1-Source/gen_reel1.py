"""KAPTAN Reel 1 — Leather test reel template (1080x1920, 15 s).
Put real footage in ./clips/<name>.mp4 (macro, water, flex, stitch, hand) and run ./build.sh.
Any missing clip is rendered as a labelled placeholder slate (animatic)."""
import os, json, subprocess, sys

ACC = '#FEE104'
# (name, in, out, placeholder instruction)
SHOTS = [
 ('macro', 0.0, 3.0, 'MACRO · leather surface · hard side light, grain visible · slow push-in'),
 ('water', 3.0, 4.7, 'WATER DROP · one drop on the product · film the real result, no edits'),
 ('flex', 4.7, 6.4, 'FLEX · bend the leather in hand · show creases, recovery'),
 ('stitch', 6.4, 8.0, 'EDGE STITCHING · macro along the seam · rack focus'),
 ('hand', 8.0, 12.0, 'HERO · hand lifts the finished product into frame · black background'),
]
HOOK = sys.argv[1] if len(sys.argv) > 1 else 'Real Leather<br>vs. Synthetic?'
LINE = sys.argv[2] if len(sys.argv) > 2 else 'Handcrafted full-grain quality.'
END = 15.0

def frames(name):
    d = f'fr/{name}'
    if os.path.isdir(d):
        n = len([f for f in os.listdir(d) if f.endswith('.jpg')])
        if n: return n
    return 0

layers = []
for name, i, o, txt in SHOTS:
    n = frames(name)
    lin = max(0, i - 0.08)
    if n:
        layers.append(f'<div class="L" data-in="{lin}" data-out="{o}" data-f="0.08"><img class="clip full" data-dir="fr/{name}" data-n="{n}"><div class="shade"></div></div>')
    else:
        layers.append(f'''<div class="L" data-in="{lin}" data-out="{o}" data-f="0.08"><div class="slate"><div class="dash"></div>
<div class="sl-k">SHOT {SHOTS.index((name,i,o,txt))+1} · {i:.1f}–{o:.1f} s</div><div class="sl-t">{txt}</div><div class="sl-f">replace with clips/{name}.mp4</div></div></div>''')

# overlays
layers.append(f'''<div class="L" data-in="0.15" data-out="3.0" data-f="0.12"><div class="ov" style="top:700px">
<div class="hook a" data-d="0.0">{HOOK}</div><div class="bar a" data-d="0.35"></div></div></div>''')
for k, (lbl, i) in enumerate([('WATER TEST', 3.0), ('FLEX TEST', 4.7), ('EDGE STITCHING', 6.4)]):
    o = [4.7, 6.4, 8.0][k]
    layers.append(f'<div class="L" data-in="{i}" data-out="{o}" data-f="0.06"><div class="tag a" data-d="0.05"><span class="no">0{k+1}</span>{lbl}</div></div>')
layers.append(f'''<div class="L" data-in="8.3" data-out="12.0" data-f="0.15"><div class="ov" style="top:1240px">
<div class="line a" data-d="0.0">{LINE}</div></div></div>''')
layers.append(f'''<div class="L" data-in="12.0" data-out="99" data-f="0.12"><div class="endc">
<div class="ybar a" data-d="0.05" style="width:520px"></div>
<img class="a logo" data-d="0.15" src="kaptan-logo.png">
<div class="end1 a" data-d="0.55">Made for the journey.</div>
<div class="url a" data-d="0.8">kaptangrp.com</div>
<div class="ybar a" data-d="0.3" style="width:220px"></div></div></div>''')
# flash frames on cuts
for t in [3.0, 4.7, 6.4, 8.0, 12.0]:
    layers.append(f'<div class="L" data-in="{t-0.02}" data-out="{t+0.1}" data-f="0.04"><div style="position:absolute;inset:0;background:{ACC};mix-blend-mode:overlay"></div></div>')

CSS = f'''
@font-face{{font-family:PF;font-weight:400;src:url(fonts/playfair-display-latin-400-normal.woff2)}}
@font-face{{font-family:PF;font-style:italic;font-weight:400;src:url(fonts/playfair-display-latin-400-italic.woff2)}}
@font-face{{font-family:IN;font-weight:700;src:url(fonts/inter-latin-700-normal.woff2)}}
@font-face{{font-family:IN;font-weight:400;src:url(fonts/inter-latin-400-normal.woff2)}}
@font-face{{font-family:JB;font-weight:500;src:url(fonts/jetbrains-mono-latin-500-normal.woff2)}}
body{{margin:0;background:#000}}
#stage{{position:relative;width:1080px;height:1920px;overflow:hidden;background:#000;color:#fff;font-family:IN,sans-serif}}
.L{{position:absolute;inset:0;opacity:0}}
.full{{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}}
.shade{{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.25),rgba(0,0,0,0) 30%,rgba(0,0,0,0) 60%,rgba(0,0,0,.55))}}
.slate{{position:absolute;inset:0;background:repeating-linear-gradient(135deg,#0d0d0d 0 28px,#121212 28px 56px);display:flex;flex-direction:column;justify-content:flex-end;padding-bottom:330px !important;box-sizing:border-box;align-items:center;gap:26px;padding:0 140px;text-align:center}}
.dash{{position:absolute;inset:90px;border:3px dashed rgba(254,225,4,.5)}}
.sl-k{{font-family:JB;font-size:30px;color:{ACC};letter-spacing:.08em}}
.sl-t{{font-size:40px;line-height:1.35;font-weight:700;color:#E8E3D6}}
.sl-f{{font-family:JB;font-size:24px;color:#8a8478}}
.ov{{position:absolute;left:90px;right:90px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:30px}}
.hook{{font-family:IN;font-weight:700;font-size:104px;line-height:1.02;text-transform:uppercase;letter-spacing:-.01em;text-shadow:0 6px 30px rgba(0,0,0,.8)}}
.bar{{width:240px;height:10px;background:{ACC}}}
.tag{{position:absolute;left:90px;top:300px;display:flex;align-items:center;gap:18px;background:#000;padding:16px 26px;font-weight:700;font-size:34px;letter-spacing:.22em;border-left:8px solid {ACC}}}
.tag .no{{font-family:JB;color:{ACC};letter-spacing:0}}
.line{{font-family:PF;font-style:italic;font-size:78px;line-height:1.1;background:rgba(0,0,0,.72);padding:22px 34px;border-bottom:6px solid {ACC}}}
.endc{{position:absolute;inset:0;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:40px}}
.logo{{width:320px;height:320px}}
.ybar{{height:8px;background:{ACC}}}
.end1{{font-family:PF;font-size:62px}}
.url{{font-family:JB;font-size:44px;color:{ACC}}}
'''
JS = '''
const END=%s;const clamp=x=>Math.max(0,Math.min(1,x));const ease=x=>1-Math.pow(1-x,3);
const Ls=[...document.querySelectorAll('.L')];
window.render=async t=>{const w=[];
 for(const L of Ls){const i=+L.dataset.in,o=+L.dataset.out,f=+L.dataset.f;const op=clamp((t-i)/f)*clamp((o-t)/f);
  L.style.opacity=op;L.style.visibility=op>0?'visible':'hidden';const lt=t-i;
  for(const e of L.querySelectorAll('.a')){const p=ease(clamp((lt-+e.dataset.d)/0.3));e.style.opacity=p;
   e.style.transform=(e.classList.contains('bar')||e.classList.contains('ybar'))?`scaleX(${p})`:e.classList.contains('logo')?`scale(${0.8+0.2*p})`:`translateY(${(1-p)*40}px) scale(${1.08-0.08*p})`;}
  const c=L.querySelector('.clip');if(c&&op>0){const n=Math.min(+c.dataset.n,Math.max(1,Math.floor(lt*30)+1));const s=c.dataset.dir+'/'+String(n).padStart(4,'0')+'.jpg';if(!c.src.endsWith(s)){c.src=s;w.push(c.decode().catch(()=>{}));}
   c.style.transform=`scale(${1.03+0.04*clamp(lt/3)})`;}
  const sl=L.querySelector('.slate');if(sl){sl.style.transform=`scale(${1.0+0.03*clamp(lt/3)})`;}
 }
 document.getElementById('fade').style.opacity=clamp((t-(END-0.3))/0.3);await Promise.all(w);};render(0);
''' % END
html = f'<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body><div id="stage">{"".join(layers)}<div id="fade" style="position:absolute;inset:0;background:#000;opacity:0"></div></div><script>{JS}</script></body></html>'
open('reel1.html', 'w').write(html)
json.dump([0, 3, 8, 12, 15], open('reel1.cuts.json', 'w'))
print('ok', {s[0]: frames(s[0]) for s in SHOTS})
