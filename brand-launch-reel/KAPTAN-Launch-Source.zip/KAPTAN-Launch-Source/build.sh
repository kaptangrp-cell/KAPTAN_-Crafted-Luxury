#!/bin/bash
# usage: ./build.sh launch_v_de OUTPUT.mp4 /path/to/Brand_Track.mp3
set -e; n=$1
python3 gen_launch.py v_de v_en h_en
node render3.js $n
: > $n.list; for i in 0 1 2 3 4 5; do echo "file '${n}_s$i.mp4'" >> $n.list; done
ffmpeg -y -f concat -safe 0 -i $n.list -c copy $n.silent.mp4
ffmpeg -y -i $n.silent.mp4 -ss 20 -t 30 -i "$3" -map 0:v -map 1:a -c:v copy -af "afade=t=in:d=0.5,afade=t=out:st=27.5:d=2.5" -c:a aac -b:a 192k -shortest -movflags +faststart "$2"
