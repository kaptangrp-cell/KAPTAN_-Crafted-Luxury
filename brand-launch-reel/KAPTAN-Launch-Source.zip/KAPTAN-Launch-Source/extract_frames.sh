#!/bin/bash
# Put your four source clips in ./clips as candle.mp4, bowl.mp4, lamp.mp4, laptop.mp4 (Kaptan_Salt_Candle_Holders_Reel, Kaptan_Salt_Bowl_Lamps_Reel, Kaptan_Salt_Lamp_Reel, Laptop_bag)
set -e; mkdir -p fr/candle fr/heart fr/bowltable fr/bowl fr/lamp st
ex(){ ffmpeg -y -loglevel error -ss $2 -t $3 -i clips/$1.mp4 -vf "$4,fps=30" -q:v 3 fr/$5/%04d.jpg; }
ex candle 11.4 4.8 "crop=1080:1080:0:0" candle
ex candle 3.5 3.3 "crop=1080:1080:0:0" heart
ex bowl 3.5 3.3 "crop=1080:1080:0:0" bowltable
ex bowl 11.3 4.8 "crop=1080:1080:0:0" bowl
ex lamp 5.2 4.8 "crop=1080:1080:0:150" lamp
for t in 0.0:man 5.45:walk 7.5:bag; do ffmpeg -y -loglevel error -ss ${t%%:*} -i clips/laptop.mp4 -frames:v 1 -vf crop=1080:604:0:373 st/${t##*:}.png; done
