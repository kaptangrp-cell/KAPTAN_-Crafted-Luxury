"""KAPTAN brand launch reel — editable source.
Generates launch_<format>_<lang>.html; render with render3.js.
Edit TEXT (copy), MEDIA (timeline) or CSS below, then re-run."""
import sys, json

TEXT = {
 'en': {
  'hook1': 'Your everyday', 'hook2': 'deserves <em>more.</em>',
  'k_leather': 'KAPTAN Leather', 'h_leather': 'Leather essentials<br>for everyday journeys.',
  'k_salt': 'KAPTAN Salt Lamps', 'h_salt': 'Salt accents<br>for a warmer home.',
  'k_work': 'Heading to work', 'h_work': 'Practical by purpose.',
  'k_move': 'On the move', 'h_move': 'Considered details.',
  'k_gift': 'A thoughtful gift', 'h_gift': 'A human answer,<br>before and after your order.',
  'k_home': 'Coming home', 'h_home': 'Care beyond checkout.',
  'line1': 'Made for the journey.', 'line2': 'Built to become yours.',
  'end1': 'Meet KAPTAN.', 'end2': 'Find your everyday companion.',
 },
 'de': {
  'hook1': 'Dein Alltag', 'hook2': 'verdient <em>mehr.</em>',
  'k_leather': 'KAPTAN Leder', 'h_leather': 'Lederbegleiter<br>für jeden Weg.',
  'k_salt': 'KAPTAN Salzlampen', 'h_salt': 'Salzlampen für ein<br>wärmeres Zuhause.',
  'k_work': 'Auf dem Weg zur Arbeit', 'h_work': 'Praktisch durchdacht.',
  'k_move': 'Unterwegs', 'h_move': 'Details, die zählen.',
  'k_gift': 'Ein Geschenk mit Bedeutung', 'h_gift': 'Persönliche Antworten –<br>vor und nach der Bestellung.',
  'k_home': 'Nach Hause kommen', 'h_home': 'Für dich da –<br>auch nach dem Kauf.',
  'line1': 'Gemacht für deinen Weg.', 'line2': 'Gebaut, um deins zu werden.',
  'end1': 'Lerne KAPTAN kennen.', 'end2': 'Finde deinen Begleiter<br>für jeden Tag.',
 },
}

# media timeline: (in, out, kind, src, extra)
MEDIA = [
 (0.0, 3.1, 'glow', 'candle', 144),
 (3.0, 4.7, 'still', 'st/bag.png', 'push'),
 (4.6, 6.1, 'still', 'st/bag.png', 'detail'),
 (6.0, 7.5, 'clip', 'heart', 99),
 (7.4, 8.8, 'clip', 'bowltable', 99),
 (8.7, 10.1, 'clip', 'lamp', 144),
 (10.0, 12.35, 'still', 'st/man.png', 'push'),
 (12.25, 14.6, 'still', 'st/walk.png', 'pan'),
 (14.5, 16.85, 'clip', 'candle', 144),
 (16.75, 19.1, 'clip', 'bowl', 144),
 (19.0, 25.1, 'still', 'st/bag.png', 'slow'),
]
CAPS = [  # (in, out, kicker key, headline key)
 (3.0, 6.0, 'k_leather', 'h_leather'),
 (6.0, 10.0, 'k_salt', 'h_salt'),
 (10.0, 12.25, 'k_work', 'h_work'),
 (12.25, 14.5, 'k_move', 'h_move'),
 (14.5, 16.75, 'k_gift', 'h_gift'),
 (16.75, 19.0, 'k_home', 'h_home'),
]
END = 30.0

CSS = r'''
@font-face{font-family:PF;font-weight:400;src:url(node_modules/@fontsource/playfair-display/files/playfair-display-latin-400-normal.woff2)}
@font-face{font-family:PF;font-weight:400;font-style:italic;src:url(node_modules/@fontsource/playfair-display/files/playfair-display-latin-400-italic.woff2)}
@font-face{font-family:IN;font-weight:400;src:url(node_modules/@fontsource/inter/files/inter-latin-400-normal.woff2)}
@font-face{font-family:IN;font-weight:700;src:url(node_modules/@fontsource/inter/files/inter-latin-700-normal.woff2)}
@font-face{font-family:JB;font-weight:500;src:url(node_modules/@fontsource/jetbrains-mono/files/jetbrains-mono-latin-500-normal.woff2)}
html,body{margin:0;background:#000}
#stage{position:relative;overflow:hidden;background:radial-gradient(ellipse at 50% 40%,#1a140a 0%,#0D0D0D 45%,#000 100%);font-family:IN,sans-serif;color:#fff}
.v #stage{width:1080px;height:1920px} .h #stage{width:1920px;height:1080px}
.L{position:absolute;inset:0;opacity:0}
.win{position:absolute;overflow:hidden;background:#000;box-shadow:0 0 0 1px rgba(201,162,39,.45),0 30px 80px rgba(0,0,0,.6)}
.win img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transform-origin:50% 50%}
.sweep{position:absolute;inset:0;background:linear-gradient(105deg,transparent 35%,rgba(228,197,90,.22) 50%,transparent 65%);mix-blend-mode:screen}
.v .wide{left:0;top:620px;width:1080px;height:604px}
.v .sq{left:110px;top:400px;width:860px;height:860px}
.h .wide{left:96px;top:216px;width:1152px;height:648px}
.h .sq{left:198px;top:150px;width:780px;height:780px}
.glowbg{position:absolute;inset:-60px;filter:blur(26px) brightness(.55)}
.glowbg img{width:100%;height:100%;object-fit:cover}
.k{font-weight:700;letter-spacing:.32em;text-transform:uppercase;color:#C9A227}
.hd{font-family:PF,serif;line-height:1.12}
.hd em{color:#E4C55A}
.a{opacity:0}
.v .cap{position:absolute;left:90px;right:90px;top:1330px;display:flex;flex-direction:column;gap:22px}
.v .cap .k{font-size:26px} .v .cap .hd{font-size:66px}
.h .cap{position:absolute;left:1320px;right:90px;top:0;bottom:0;display:flex;flex-direction:column;justify-content:center;gap:24px}
.h .cap .k{font-size:20px} .h .cap .hd{font-size:50px} .h .cap .big{font-size:48px}
.rule{width:90px;height:2px;background:#C9A227}
.center{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:30px;padding:0 90px;box-sizing:border-box}
.v .hook{font-size:120px} .h .hook{font-size:110px}
.v .big{font-size:84px} .h .big{font-size:76px}
.mono{font-family:JB,monospace;font-weight:500;color:#C9A227}
.bar{height:2px;background:#C9A227;transform-origin:50% 50%}
'''

JS = r'''
const END=__END__;
const clamp=x=>Math.max(0,Math.min(1,x));const ease=x=>1-Math.pow(1-x,3);
let seed=11;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};
const W=document.getElementById('stage').clientWidth,H=document.getElementById('stage').clientHeight;
const dust=[...Array(70)].map(()=>({x:rnd()*W,y:rnd()*H,v:10+rnd()*22,r:.8+rnd()*2.2,a:.15+rnd()*.4,w:rnd()*6.28}));
const Ls=[...document.querySelectorAll('.L')];
window.render=async(t)=>{const waits=[];
 for(const L of Ls){const i=+L.dataset.in,o=+L.dataset.out,f=+(L.dataset.f||0.25);
  const op=clamp((t-i)/f)*clamp((o-t)/f);L.style.opacity=op;L.style.visibility=op>0?'visible':'hidden';
  const lt=t-i,q=clamp(lt/(o-i));
  for(const e of L.querySelectorAll('.a')){const p=ease(clamp((lt-(+e.dataset.d))/0.6));e.style.opacity=p;
    e.style.transform=e.classList.contains('bar')?`scaleX(${p})`:`translateY(${(1-p)*30}px)`;}
  const w=L.querySelector('.win');if(w){const p=ease(clamp(lt/0.5));w.style.transform=`scale(${1.05-0.05*p})`;}
  const s=L.querySelector('.still');if(s){const m=s.dataset.m;
    s.style.transform=m==='detail'?`scale(${1.55+0.08*q}) translate(0,${4-6*q}%)`:m==='pan'?`scale(1.12) translateX(${3-6*q}%)`:m==='slow'?`scale(${1.0+0.08*q})`:`scale(${1.02+0.07*q})`;}
  const sw=L.querySelector('.sweep');if(sw){sw.style.transform=`translateX(${-120+240*clamp((lt-0.3)/1.4)}%)`;}
  const c=L.querySelector('.clip');if(c&&op>0){const n=Math.min(+c.dataset.n,Math.max(1,Math.floor(lt*30)+1));const src=c.dataset.dir+'/'+String(n).padStart(4,'0')+'.jpg';if(!c.src.endsWith(src)){c.src=src;waits.push(c.decode().catch(()=>{}));}}
 }
 const cv=document.getElementById('dust').getContext('2d');cv.clearRect(0,0,W,H);
 for(const d of dust){const y=((d.y-d.v*t)%H+H)%H,x=d.x+Math.sin(d.w+t*.5)*14;cv.beginPath();cv.arc(x,y,d.r,0,6.283);cv.fillStyle=`rgba(228,197,90,${d.a})`;cv.fill();}
 document.getElementById('fade').style.opacity=clamp((t-(END-0.6))/0.6);
 await Promise.all(waits);};
render(0);
'''

def media_layer(m):
    i, o, kind, src, x = m
    if kind == 'glow':
        return f'<div class="L" data-in="{i}" data-out="{o}" data-f="0.01"><div class="glowbg"><img class="clip" data-dir="fr/{src}" data-n="{x}"></div></div>'
    if kind == 'clip':
        return f'<div class="L" data-in="{i}" data-out="{o}"><div class="win sq"><img class="clip" data-dir="fr/{src}" data-n="{x}"></div></div>'
    sweep = '<div class="sweep"></div>' if x in ('push', 'slow') and 'bag' in src else ''
    return f'<div class="L" data-in="{i}" data-out="{o}"><div class="win wide"><img class="still" data-m="{x}" src="{src}">{sweep}</div></div>'

def build(fmt, lang):
    T = TEXT[lang]
    out = []
    for m in MEDIA: out.append(media_layer(m))
    for i, o, k, h in CAPS:
        out.append(f'<div class="L" data-in="{i}" data-out="{o}" data-f="0.2"><div class="cap"><div class="k a" data-d="0.1">{T[k]}</div><div class="hd a" data-d="0.25">{T[h]}</div></div></div>')
    # persistent small logo mark (3–25 s)
    out.append('<div class="L" data-in="3.0" data-out="25.0" data-f="0.4"><img src="kaptan-logo.png" style="position:absolute;' + ('left:490px;top:230px;width:100px;height:100px' if fmt=='v' else 'left:1320px;top:96px;width:96px;height:96px') + '"></div>')
    # hook
    out.append(f'''<div class="L" data-in="0" data-out="3.0" data-f="0.2"><div class="center">
<div class="hd hook a" data-d="0.25">{T['hook1']}</div><div class="bar a" data-d="0.9" style="width:180px"></div>
<div class="hd hook a" data-d="1.0" style="font-style:italic">{T['hook2']}</div></div></div>''')
    # line 19-25 (over bag still, text in caption area)
    out.append(f'''<div class="L" data-in="19.0" data-out="25.0" data-f="0.3"><div class="cap">
<div class="hd big a" data-d="0.4">{T['line1']}</div><div class="hd big a" data-d="1.6" style="font-style:italic;color:#E4C55A">{T['line2']}</div></div></div>''')
    # end card
    out.append(f'''<div class="L" data-in="25.0" data-out="99" data-f="0.4"><div class="center" style="gap:34px">
<img class="a" data-d="0.2" src="kaptan-logo.png" style="width:300px;height:300px">
<div class="hd big a" data-d="0.9">{T['end1']}</div>
<div class="hd a" data-d="1.4" style="font-size:{56 if fmt=='v' else 48}px;font-style:italic;color:#E8E3D6">{T['end2']}</div>
<div class="rule a" data-d="1.9"></div>
<div class="mono a" data-d="2.1" style="font-size:{46 if fmt=='v' else 40}px">kaptangrp.com</div></div></div>''')
    html = f'''<!doctype html><html lang="{lang}"><head><meta charset="utf-8"><title>KAPTAN launch reel {fmt}-{lang}</title><style>{CSS}</style></head>
<body class="{fmt}"><div id="stage">
{chr(10).join(out)}
<canvas id="dust" width="{1080 if fmt=='v' else 1920}" height="{1920 if fmt=='v' else 1080}" style="position:absolute;inset:0"></canvas>
<div id="fade" style="position:absolute;inset:0;background:#000;opacity:0"></div>
</div><script>{JS.replace('__END__', str(END))}</script></body></html>'''
    name = f'launch_{fmt}_{lang}'
    open(name + '.html', 'w').write(html)
    # scene cuts for chunked encoding (every ~5 s on frame boundaries)
    json.dump([0, 5, 10, 15, 20, 25, 30], open(name + '.cuts.json', 'w'))
    print(name)

for spec in sys.argv[1:]:
    f, l = spec.split('_'); build(f, l)
