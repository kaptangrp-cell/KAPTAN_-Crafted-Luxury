const {chromium}=require('playwright');const {spawn}=require('child_process');const fs=require('fs');
const name=process.argv[2];const cuts=JSON.parse(fs.readFileSync(name+'.cuts.json'));
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:(name.includes('_v_')?{width:1080,height:1920}:{width:1920,height:1080})});
await p.goto('file://'+process.cwd()+'/'+name+'.html');await p.evaluate(()=>document.fonts.ready);await p.waitForTimeout(300);
if(process.argv[3]==='preview'){for(const t of process.argv.slice(4)){await p.evaluate(t=>render(+t),t);await p.screenshot({path:`pv_${name}_${t}.jpg`,type:'jpeg',quality:80});}await b.close();return;}
for(let s=0;s<cuts.length-1;s++){
  const f0=Math.round(cuts[s]*30),f1=Math.round(cuts[s+1]*30);const tmp=`${name}_s${s}.tmp.mp4`;
  const ff=spawn('ffmpeg',['-y','-loglevel','error','-f','image2pipe','-framerate','30','-c:v','mjpeg','-i','-','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-r','30',tmp]);
  for(let f=f0;f<f1;f++){await p.evaluate(t=>render(t),f/30);const buf=await p.screenshot({type:'jpeg',quality:92});if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));}
  ff.stdin.end();const code=await new Promise(r=>ff.on('close',r));if(code!==0)throw new Error('ffmpeg');fs.renameSync(tmp,`${name}_s${s}.mp4`);
}
console.log(name,'done',cuts.length-1);await b.close()})()
